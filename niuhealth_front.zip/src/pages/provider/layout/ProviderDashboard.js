import { Outlet } from "react-router-dom"
import SideNav from "./SideNav"
import TopBar from "./TopBar"

function ProviderDashboard() {
  return (
    <div style={{ display: "flex", width: "100vw" }}>
      <TopBar />
      <SideNav />
      <div>
        <Outlet />
      </div>
    </div>
  )
}

export default ProviderDashboard
