function Footer() {
  return (
    <footer className="footer text-center text-sm-left">
      &copy; 2022 NU Health
    </footer>
  )
}

export default Footer
