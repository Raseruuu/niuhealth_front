import imgLogo from "../assets/images/nu-health-logo.png"

function SideNavLogo() {
  return <img src={imgLogo} alt="logo-small" className="logo-sm" />
}

export default SideNavLogo
